package prueba1;

public class ejer1 {
    public static void main(String[] args) {
        int numeroentero= 8;
        System.out.println(numeroentero);

        double numerodecimal= 12.50;
        System.out.println(numerodecimal);

        String cadenadepalabras="esto es un string";
        System.out.println(cadenadepalabras);

        boolean soymayor=true;
        System.out.println(soymayor);

    }
}
